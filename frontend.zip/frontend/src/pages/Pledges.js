import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

const Pledges = () => {
  const { user, updateUser } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState('all');

  const mockPledges = [
    {
      id: 1,
      title: 'No Plastic for 7 Days',
      description: 'Avoid single-use plastic items for a week',
      category: 'waste-reduction',
      duration: 7,
      difficulty: 'easy',
      estimatedCO2Saving: 5.2,
      icon: '🚫',
      color: '#EF4444',
      points: 50
    },
    {
      id: 2,
      title: 'Walk Instead of Drive',
      description: 'Walk or bike for short trips under 2km',
      category: 'transportation',
      duration: 14,
      difficulty: 'medium',
      estimatedCO2Saving: 12.8,
      icon: '🚶',
      color: '#3B82F6',
      points: 100
    },
    {
      id: 3,
      title: 'Plant a Tree',
      description: 'Plant and care for a tree in your community',
      category: 'nature-protection',
      duration: 1,
      difficulty: 'easy',
      estimatedCO2Saving: 22.0,
      icon: '🌳',
      color: '#10B981',
      points: 200
    },
    {
      id: 4,
      title: 'Energy Saving Week',
      description: 'Reduce energy consumption by 20% for a week',
      category: 'energy-saving',
      duration: 7,
      difficulty: 'medium',
      estimatedCO2Saving: 8.5,
      icon: '💡',
      color: '#F59E0B',
      points: 75
    }
  ];

  const categories = [
    { id: 'all', name: 'All Categories', icon: '🌍' },
    { id: 'waste-reduction', name: 'Waste Reduction', icon: '♻️' },
    { id: 'transportation', name: 'Transportation', icon: '🚲' },
    { id: 'energy-saving', name: 'Energy Saving', icon: '💡' },
    { id: 'nature-protection', name: 'Nature Protection', icon: '🌳' }
  ];

  const filteredPledges = selectedCategory === 'all' 
    ? mockPledges 
    : mockPledges.filter(pledge => pledge.category === selectedCategory);

  const handleJoinPledge = (pledge) => {
    // Mock joining a pledge
    alert(`Joined pledge: ${pledge.title}! Start tracking your progress.`);
    
    // Update user stats (mock)
    updateUser({
      totalActions: (user.totalActions || 0) + 1,
      totalCO2Saved: (user.totalCO2Saved || 0) + pledge.estimatedCO2Saving
    });
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Available Pledges 🎯
        </h1>
        <p className="text-gray-600">
          Choose eco-friendly pledges to start your green journey!
        </p>
      </div>

      {/* Category Filter */}
      <div className="mb-8">
        <div className="flex flex-wrap gap-3">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category.id
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {category.icon} {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Pledges Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPledges.map(pledge => (
          <div key={pledge.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
            <div 
              className="h-2"
              style={{ backgroundColor: pledge.color }}
            ></div>
            
            <div className="p-6">
              <div className="flex items-center mb-3">
                <span className="text-2xl mr-3">{pledge.icon}</span>
                <div>
                  <h3 className="font-semibold text-gray-800">{pledge.title}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    pledge.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                    pledge.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {pledge.difficulty}
                  </span>
                </div>
              </div>
              
              <p className="text-gray-600 text-sm mb-4">{pledge.description}</p>
              
              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Duration:</span>
                  <span className="font-medium">{pledge.duration} day{pledge.duration > 1 ? 's' : ''}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">CO₂ Saving:</span>
                  <span className="font-medium text-green-600">{pledge.estimatedCO2Saving} kg</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Points:</span>
                  <span className="font-medium text-blue-600">{pledge.points}</span>
                </div>
              </div>
              
              <button
                onClick={() => handleJoinPledge(pledge)}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium transition-colors"
              >
                Join Pledge
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredPledges.length === 0 && (
        <div className="text-center py-12">
          <div className="text-4xl mb-4">🔍</div>
          <h3 className="text-xl font-medium text-gray-800 mb-2">No pledges found</h3>
          <p className="text-gray-600">Try selecting a different category.</p>
        </div>
      )}
    </div>
  );
};

export default Pledges;
