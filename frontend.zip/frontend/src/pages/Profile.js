import React from 'react';
import { useAuth } from '../context/AuthContext';

const Profile = () => {
  const { user } = useAuth();

  const mockBadges = [
    { id: 1, name: 'First Steps', icon: '👶', description: 'Completed your first pledge', rarity: 'common' },
    { id: 2, name: 'Eco Warrior', icon: '⚔️', description: 'Completed 5 pledges', rarity: 'rare' },
    { id: 3, name: 'Tree Hugger', icon: '🌳', description: 'Planted your first tree', rarity: 'epic' }
  ];

  const mockStats = {
    totalActions: user?.totalActions || 0,
    totalCO2Saved: user?.totalCO2Saved || 0,
    activePledges: 2,
    completedPledges: 3,
    currentStreak: 7,
    longestStreak: 15
  };

  const getRarityColor = (rarity) => {
    switch (rarity) {
      case 'common': return 'bg-gray-100 text-gray-800';
      case 'rare': return 'bg-blue-100 text-blue-800';
      case 'epic': return 'bg-purple-100 text-purple-800';
      case 'legendary': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Profile Header */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex items-center space-x-6">
          <img 
            src={user?.photoURL} 
            alt={user?.displayName}
            className="w-20 h-20 rounded-full"
          />
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-800">{user?.displayName}</h1>
            <p className="text-gray-600">{user?.email}</p>
            <div className="flex items-center mt-2">
              <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                Level {user?.level || 1}
              </span>
              <span className="ml-3 text-sm text-gray-500">
                Member since {new Date(user?.joinedAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">{mockStats.totalActions}</div>
          <div className="text-gray-600">Total Actions</div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <div className="text-3xl font-bold text-blue-600 mb-2">{mockStats.totalCO2Saved} kg</div>
          <div className="text-gray-600">CO₂ Saved</div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <div className="text-3xl font-bold text-orange-600 mb-2">{mockStats.currentStreak}</div>
          <div className="text-gray-600">Current Streak</div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Badges */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Earned Badges 🏆</h2>
          <div className="grid grid-cols-2 gap-4">
            {mockBadges.map(badge => (
              <div key={badge.id} className="border rounded-lg p-4 text-center hover:shadow-md transition-shadow">
                <div className="text-3xl mb-2">{badge.icon}</div>
                <h3 className="font-medium text-gray-800 mb-1">{badge.name}</h3>
                <p className="text-xs text-gray-600 mb-2">{badge.description}</p>
                <span className={`text-xs px-2 py-1 rounded-full ${getRarityColor(badge.rarity)}`}>
                  {badge.rarity}
                </span>
              </div>
            ))}
          </div>
          {mockBadges.length === 0 && (
            <p className="text-gray-500 text-center py-8">
              No badges earned yet. Complete pledges to earn your first badge!
            </p>
          )}
        </div>

        {/* Detailed Stats */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Detailed Statistics 📊</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Active Pledges</span>
              <span className="font-semibold text-green-600">{mockStats.activePledges}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Completed Pledges</span>
              <span className="font-semibold text-blue-600">{mockStats.completedPledges}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Longest Streak</span>
              <span className="font-semibold text-orange-600">{mockStats.longestStreak} days</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Badges</span>
              <span className="font-semibold text-purple-600">{mockBadges.length}</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t">
            <h3 className="font-medium text-gray-800 mb-3">Environmental Impact</h3>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 mb-1">
                  {mockStats.totalCO2Saved} kg CO₂
                </div>
                <div className="text-sm text-gray-600">
                  Equivalent to planting {Math.round(mockStats.totalCO2Saved / 22)} trees! 🌳
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-8 bg-gradient-to-r from-green-500 to-blue-500 p-6 rounded-lg text-white text-center">
        <h2 className="text-xl font-semibold mb-4">Keep Going! 🚀</h2>
        <p className="mb-4">You're making a real difference for our planet!</p>
        <div className="flex justify-center space-x-4">
          <button className="bg-white bg-opacity-20 hover:bg-opacity-30 px-6 py-2 rounded-lg transition-colors">
            Share Progress
          </button>
          <button className="bg-white bg-opacity-20 hover:bg-opacity-30 px-6 py-2 rounded-lg transition-colors">
            Invite Friends
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
