import React from 'react';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();

  const mockPledges = [
    { id: 1, title: 'No Plastic for 7 Days', progress: 5, total: 7, category: 'waste-reduction' },
    { id: 2, title: 'Walk Instead of Drive', progress: 3, total: 14, category: 'transportation' },
  ];

  const mockRecentActions = [
    { id: 1, title: 'Used reusable water bottle', co2Saved: 0.5, date: '2024-01-15' },
    { id: 2, title: 'Walked to work', co2Saved: 2.1, date: '2024-01-14' },
    { id: 3, title: 'Recycled plastic bottles', co2Saved: 0.8, date: '2024-01-13' },
  ];

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Welcome back, {user?.displayName}! 🌱
        </h1>
        <p className="text-gray-600">
          Keep up the great work on your eco-friendly journey!
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-2xl font-bold text-green-600 mb-1">
            {user?.totalActions || 0}
          </div>
          <div className="text-sm text-gray-600">Total Actions</div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-2xl font-bold text-blue-600 mb-1">
            {user?.totalCO2Saved || 0} kg
          </div>
          <div className="text-sm text-gray-600">CO₂ Saved</div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-2xl font-bold text-purple-600 mb-1">
            {user?.badges?.length || 0}
          </div>
          <div className="text-sm text-gray-600">Badges Earned</div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-2xl font-bold text-orange-600 mb-1">
            Level {user?.level || 1}
          </div>
          <div className="text-sm text-gray-600">Current Level</div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Active Pledges */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Active Pledges</h2>
          <div className="space-y-4">
            {mockPledges.map(pledge => (
              <div key={pledge.id} className="border-l-4 border-green-500 pl-4">
                <h3 className="font-medium text-gray-800">{pledge.title}</h3>
                <div className="flex items-center mt-2">
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${(pledge.progress / pledge.total) * 100}%` }}
                    ></div>
                  </div>
                  <span className="ml-3 text-sm text-gray-600">
                    {pledge.progress}/{pledge.total} days
                  </span>
                </div>
              </div>
            ))}
            {mockPledges.length === 0 && (
              <p className="text-gray-500 text-center py-4">
                No active pledges. Visit the Pledges page to get started!
              </p>
            )}
          </div>
        </div>

        {/* Recent Actions */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Recent Actions</h2>
          <div className="space-y-3">
            {mockRecentActions.map(action => (
              <div key={action.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                <div>
                  <h3 className="font-medium text-gray-800">{action.title}</h3>
                  <p className="text-sm text-gray-600">{action.date}</p>
                </div>
                <div className="text-green-600 font-semibold">
                  -{action.co2Saved} kg CO₂
                </div>
              </div>
            ))}
            {mockRecentActions.length === 0 && (
              <p className="text-gray-500 text-center py-4">
                No actions logged yet. Start tracking your green actions!
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 bg-gradient-to-r from-green-500 to-blue-500 p-6 rounded-lg text-white">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <button className="bg-white bg-opacity-20 hover:bg-opacity-30 p-4 rounded-lg transition-colors">
            <div className="text-2xl mb-2">📝</div>
            <div className="font-medium">Log Action</div>
          </button>
          <button className="bg-white bg-opacity-20 hover:bg-opacity-30 p-4 rounded-lg transition-colors">
            <div className="text-2xl mb-2">🎯</div>
            <div className="font-medium">New Pledge</div>
          </button>
          <button className="bg-white bg-opacity-20 hover:bg-opacity-30 p-4 rounded-lg transition-colors">
            <div className="text-2xl mb-2">🏆</div>
            <div className="font-medium">View Leaderboard</div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
