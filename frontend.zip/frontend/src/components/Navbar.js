import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-green-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="text-2xl font-bold">
            🌱 Green Pledge
          </Link>
          
          <div className="flex items-center space-x-6">
            <Link to="/" className="hover:text-green-200 transition-colors">
              Home
            </Link>
            
            {user ? (
              <>
                <Link to="/dashboard" className="hover:text-green-200 transition-colors">
                  Dashboard
                </Link>
                <Link to="/pledges" className="hover:text-green-200 transition-colors">
                  Pledges
                </Link>
                <Link to="/profile" className="hover:text-green-200 transition-colors">
                  Profile
                </Link>
                <div className="flex items-center space-x-3">
                  <img 
                    src={user.photoURL} 
                    alt={user.displayName}
                    className="w-8 h-8 rounded-full"
                  />
                  <span className="text-sm">{user.displayName}</span>
                  <button 
                    onClick={handleLogout}
                    className="bg-green-700 hover:bg-green-800 px-3 py-1 rounded text-sm transition-colors"
                  >
                    Logout
                  </button>
                </div>
              </>
            ) : (
              <Link 
                to="/login" 
                className="bg-green-700 hover:bg-green-800 px-4 py-2 rounded transition-colors"
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
